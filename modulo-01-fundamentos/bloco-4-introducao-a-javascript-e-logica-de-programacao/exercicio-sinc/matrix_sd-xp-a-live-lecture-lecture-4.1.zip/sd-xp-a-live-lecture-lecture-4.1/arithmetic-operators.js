let num1 = 5;
let num2 = 10;
let num3 = 15;

// // Soma
// let sum = num1 + num2;
// console.log(sum);

// // Subtração
// let subtraction = num1 - num2;
// console.log(subtraction);

// // Divisão
// let division = num1 / num2;
// console.log(division);

// // Multiplicação
// let multiplication = num1 * num2;
// console.log(multiplication);

// // Operador de relação
// let comparison = num1 < num2;
// console.log(comparison);

// // Como saber se o número é par?
// let isEven = ((num1 + num2) % 2) === 0;
// console.log(isEven);
