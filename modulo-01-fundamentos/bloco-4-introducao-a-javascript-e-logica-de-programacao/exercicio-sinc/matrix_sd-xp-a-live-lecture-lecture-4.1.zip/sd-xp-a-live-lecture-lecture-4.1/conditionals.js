let age = 17;

if (age >= 18) {
  console.log('Pode dirigir!');
} else {
  console.log('Não pode dirigir!');
}
