let weekDay = 4;

switch (weekDay) {
  case 1:
    console.log('Domingo');
    break;
  case 2:
    console.log('Segunda-feira');
    break;
  case 3:
    console.log('Terça-feira');
    break;
  case 4:
    console.log('Quarta-feira');
    break;
  case 5:
    console.log('Quinta-feira');
    break;
  case 6:
    console.log('Dia de maldade');
    break;
  case 7:
    console.log('Sábado');
    break;
  default:
    console.log('Não existe esse dia, ainda');
    break;
}
